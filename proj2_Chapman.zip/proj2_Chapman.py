#Josh Chapman
#10/7/2021
#CS307
#Project2

# Import pandas
from os import stat
import pandas as pd

#read excel file
xl1 = pd.read_excel('2018_crime_stats.xlsx')
xl2 = pd.read_excel('publicspreadsheet.xlsx')

#print some instace
#print(xl1.iloc[0])

conv = len(xl1)

exon = len(xl2)

exon2018 = len(xl2[xl2["Exonerated"] == 2018])

#this is the universal p(exonerated) value, set here by 2018 exonerations over 2018 convictions
pExon = round(exon2018/conv*100, 2)

#xl2.iloc[0]["Age"]

#computes p(thing1|exonerated) as # of thing1s that have been exonerated/total exonerations
def pThing1Exon(thing1, category):
    thingtot = 0
    for i in range(0, len(xl2)):
        if xl2.iloc[i][category] == thing1:
            thingtot+=1
    return thingtot/exon

#computes p(agerange|exonerated) same as above, but with a range of values
def pAgeRangeExon(ageLow, ageHigh):
    agerangetot = 0
    for i in range(0, len(xl2)):
        if ageLow < xl2.iloc[i]["Age"] < ageHigh:
            agerangetot+=1
    return agerangetot/exon

#method to check lists, used to create list to store values in main
def isNotIn(thing, list):
    for i in range(0, len(list)):
        if thing == list[i]:
            return False
    return True

#prints lists iteratively
def printList(list):
    for i in range(0, len(list)):
        print(list[i])
    print()

#prints out max values for each variable, then full lists
def main():
    race = ["Black", "White", "Hispanic", "Asian", "Native American", "Other"]
    maxrace = [0,0]
    for i in range(0, len(race)):
        temp = pThing1Exon(race[i], "Race")
        if temp > maxrace[0]:
            maxrace = [temp, race[i]]
        race[i] = [temp, race[i]]
    print(maxrace)

    states = []
    for i in range(0, len(xl2)):
        temp = xl2.iloc[i]["State"]
        if isNotIn(temp, states):
            states.append(temp)
    
    maxstate = [0,0]
    for i in range(0, len(states)):
        temp = pThing1Exon(states[i], "State")
        if temp > maxstate[0]:
            maxstate = [temp, states[i]]
        states[i] = [temp, states[i]]
    print(maxstate)

    sex = ["Male", "Female"]
    maxsex = [0,0]
    for i in range(0, len(sex)):
        temp = pThing1Exon(sex[i], "Sex")
        if temp > maxsex[0]:
            maxsex = [temp, sex[i]]
        sex[i] = [temp, sex[i]]
    print(maxsex)

    age = [10, 20, 30, 40, 50, 200]
    maxage = [0,0,0]
    for i in range(0, len(age)-1):
        temp = pAgeRangeExon(age[i], age[i+1])
        if temp > maxage[0]:
            maxage = [temp, age[i], age[i+1]]
        age[i] = [temp, age[i], age[i+1]]
    print(maxage)

    crimes = []
    for i in range(0, len(xl2)):
        temp = xl2.iloc[i]["Worst Crime Display"]
        if isNotIn(temp, crimes):
            crimes.append(temp)

    maxcrime = [0,0]
    for i in range(0, len(crimes)):
        temp = pThing1Exon(crimes[i], "Worst Crime Display")
        if temp > maxcrime[0]:
            maxcrime = [temp, crimes[i]]
        crimes[i] = [temp, crimes[i]]
    print(maxcrime)

    printList(race)
    printList(states)
    printList(sex)
    printList(age)
    printList(crimes)

main()