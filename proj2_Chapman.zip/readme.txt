During this exercise, I sought to produce a max value for each category, finding it by comparing the
probability of each possible value/variable. For example, I sought the most probable race to be
exonerated by comparing the probabilities of each race.

The major decision points were the problem with having only 1 year of conviction data
while having decades of exoneration data, what to do in regards to the age variable, and
how to reorganize the massive excel file to ease the work for my computer.

For the conviction/exoneration problem, I chose to only include the exonerations from
2018 when computing the value of p(exonerated), since including other years of exonerations
might inflate the p(exonerated) value.

For the ages, I chose to create 10 year bins, starting at 10 years old (too young, but covers all extremes),
and iterating to 50 years old, where anyone 50+ is considered 'elderly' if you will.

For the Excel file, I copied the desired columns from the larger sheet over to a blank book
so that the processing time for reading the file was greatly reduced.

My algorithm compares and prints values for the p(thing|exonerated) in the main function, since
the p(exonerated) is a constant across all instances, and the numerator (p(thing)) is proportional to
p(thing|exon)*p(exon). By finding the categories that maximize probability for each variable,
I find the combination that will maximize the value returned when computing Bayes for a naive bayes
classifier.
My findings are that the most likely type of person to be exonerated based on race, state/district, sex,
age range, and worst crime is a 20-30 year old Black Man convicted of Murder in Texas. 
